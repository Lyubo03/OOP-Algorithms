﻿using System;

namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //var sportCar = new SprotCar(100, 100);
            //var raceMotorcycle = new RaceMotorcycle(100, 100);
            //var car = new Car(100,100);
            //var crossMotorcycle = new CrossMotorcycle(100, 100);
            //sportCar.Drive(10); Console.WriteLine(sportCar.Fuel);
            //raceMotorcycle.Drive(10); Console.WriteLine(raceMotorcycle.Fuel);
            //car.Drive(10); Console.WriteLine(car.Fuel);
            //crossMotorcycle.Drive(10); Console.WriteLine(crossMotorcycle.Fuel);
        }
    }
}
