﻿namespace Wild_Farm.Core
{
    public interface IEngine 
    {
        public void Run();
    }
}