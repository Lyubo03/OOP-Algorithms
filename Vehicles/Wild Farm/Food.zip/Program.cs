﻿namespace Wild_Farm
{
    using Wild_Farm.Core;

    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}