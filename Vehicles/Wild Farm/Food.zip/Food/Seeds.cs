﻿namespace Wild_Farm.Food
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}