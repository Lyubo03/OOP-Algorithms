﻿using System.Globalization;

namespace Shapes
{
    public class Rectangle : Shapes
    {
        private double hight;
        private double width;

        public Rectangle(double hight, double width)
        {
            this.hight = hight;
            this.width = width;
        }
        public double Height => this.hight;
        public double Width => this.width;
        public override double CalculateArea()
        {
            return hight * width;
        }

        public override double CalculatePerimeter()
        {
            return width * 2 + hight * 2;
        }
        public sealed override string Draw()
        {
            return base.Draw() + "Rectangle";
        }
    }
}