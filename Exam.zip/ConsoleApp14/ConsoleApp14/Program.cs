﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ConsoleApp13
{
    class Program
    {
        static bool EqualElements(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                for (int w = 0; w < arr.Length; w++)
                {
                    if (arr[i] == arr[w] && i != w)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        static int[] ThirdArray(int[] a, int[] b)
        {
            int[] c = new int[a.Length];
            for (int i = 0; i < a.Length; i++)
            {
                c[i] = a[i] + b[i];
            }
            return c;
        }
        static void Main(string[] args)
        {
            int k = int.Parse(Console.ReadLine());
            int[] a = new int[k];
            int[] b = new int[k];
            for (int i = 0; i < k; i++)
            {
                int n = i * 2 + 1;
                a[i] = n;
            }
            for (int i = 0; i < k; i++)
            {
                int n = i * 2 - 1;
                b[i] = n;
            }
            Console.WriteLine(EqualElements(a));
            Console.WriteLine(EqualElements(b));
            int[] c = ThirdArray(a, b);
            Console.WriteLine(string.Join(", ", c));
        }
    }
}